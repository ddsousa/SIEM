<div id="footer" class="menu">
  <ul class="centered">
    <li class="with-separator"><a href="mailto:oceanohipermercado@gmail.com?subject=Contacto com Oceano Supermercado">Contactos</a></li>
    <li><a href="../../pages/other/report.php?menu=Relatorio"/>Relatório</a></li>
  </ul>
</div>
</div>
</body>
</html>
