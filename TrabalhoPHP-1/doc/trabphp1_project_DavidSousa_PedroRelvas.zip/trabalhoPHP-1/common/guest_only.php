<?php
  if(!isset($_SESSION['PERMISSIONS'])) {
    header("Location: ../../");
    exit;
  }
?>
