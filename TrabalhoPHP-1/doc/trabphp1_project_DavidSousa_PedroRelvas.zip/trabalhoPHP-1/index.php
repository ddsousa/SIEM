<?php
  header('Location: pages/common/home.php');
?>
