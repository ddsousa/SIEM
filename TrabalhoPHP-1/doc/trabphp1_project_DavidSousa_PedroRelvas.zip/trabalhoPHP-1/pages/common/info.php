<?php
  include_once('../../common/init.php');
  include_once ($BASE_DIR . "/common/header.php");
  include_once ($BASE_DIR . "/common/navbar.php");
  include_once ($BASE_DIR . "/common/messages.php");
?>
<div id="info">
	<a href="../../"><h3>Retornar para a página inicial</h3></a>
</div>
<?php
  include_once ($BASE_DIR . "/common/footer.php");
?>
